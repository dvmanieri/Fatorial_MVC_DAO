package principal;

import controller.FatorialController;

public class main {

	public static void main(String[] args) {
		// Crie um sistema de cálculo de fatorial que armazene os últimos 5 fatoriais
		// calculados.

		// aqui eu instancio um objeto de FatorialController
		FatorialController fatorial = new FatorialController();

	}

}

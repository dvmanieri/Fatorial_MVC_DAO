/**
 * 
 */
/**
 * @author Dvmanieri
 *
 */
module DaoFatorial {
}
package controller;

import java.util.InputMismatchException;
import java.util.Scanner;

import dao.FatorialDao;
import model.Fatorial;
import view.FatorialView;

public class FatorialController {

	// aqui eu crio dois objetos, um do tipo View e o outro do tipo Dao
	FatorialDao fatorialDao;
	FatorialView fatorialView;

	// aqui eu intancio esses objetos apenas quando é criado um objeto dessa classe
	// - para não usar muita memória -
	public FatorialController() {
		fatorialDao = new FatorialDao();
		fatorialView = new FatorialView();

		// aqui eu chamo o método que inicializa o programa
		iniciar();
	}

	// eu mando o numero recebido pelo parametro para o meu Dao guardar na lista
	public void criarFatoria(int num) {
		Fatorial fatorial = new Fatorial(num);
		fatorialDao.adicionarLista(fatorial);
	}

	// aqui inicia o programa
	public void iniciar() {

		fatorialView.saudacao();

		Scanner scan = new Scanner(System.in);

		int cont = -1;
		// aqui eu faço um laço de repetição para deixar o menu em loop
		while (cont != 0) {

			fatorialView.menu();

			// aqui eu faço um tratamento de excessão para se caso o usuário digitar uma
			// String em vez de Int
			try {
				cont = scan.nextInt();

			} catch (InputMismatchException e) {
				System.err.println("Erro ao registrar o numero, tente novamente.");
				scan.nextLine();

			}

			// aqui eu verifico a opção escolhida pelo usuário
			if (cont == 1) {
				fatorialView.opcaoUm();
				int numFatorial = scan.nextInt();

				// aqui faço outro tratamento para evitar que o usúario digite número negativo
				if (numFatorial > 0) {

					int num = numFatorial;
					int fatorial = 1;
					// aqui eu calculo o fatorial
					for (int i = num; i > 0; i--) {

						fatorial = fatorial * i;
					}
					// aqui eu passo para o método que envia para a minha lista no Dao
					criarFatoria(fatorial);
				} else {
					System.err.println("\nNao e permitido numero negativo\n");
				}

			} else if (cont == 2) {
				// aqui eu mando a lista recebida do Dao para o View
				fatorialView.opcaoDois(fatorialDao.retornaLista());
			} else if (cont == 0) {
				// aqui é uma mensagem para sair do sistema
				fatorialView.opcaoTres();
			} else {
				// aqui é uam mensagem para se caso digitar um número inválido
				fatorialView.numeroInvalido();
			}

		}

	}
}

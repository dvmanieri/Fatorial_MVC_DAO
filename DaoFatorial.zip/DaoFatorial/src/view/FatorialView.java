package view;

import java.util.List;

import model.Fatorial;

public class FatorialView {

	// aqui é aonde eu coloquei todas as minhas mensagens para mostrar no meu
	// programa

	public void saudacao() {
		System.out.println("Seja bem vindo ao seu registrador de Fatorial!");
	}

	public void menu() {

		System.out.println("1. Calcular fatorial.");
		System.out.println("2. Exibir as ultimas contas efetuadas. ");
		System.out.println("0. Sair");
		System.out.println("\nDigite uma opcaoo.");
	}

	public void opcaoUm() {
		System.out.println("\nDigite o numero no qual você deseja ver o fatorial");
	}

	// aqui eu recebo a lista do meu Dao atravéz do controller e exibo ela na tela
	public void opcaoDois(List<Fatorial> listaFatoriais) {
		System.out.println("\n=== LISTA DOS FATORIAIS ===");
		int cont = 0;
		for (Fatorial fatorial : listaFatoriais) {
			cont++;
			System.out.println(cont + ". " + fatorial.getNum());
		}
		System.out.println("============================\n");
	}

	public void opcaoTres() {
		System.out.println("\nSaindo do sistema...");
	}

	public void numeroInvalido() {
		System.out.println("numero invalido");
	}

}

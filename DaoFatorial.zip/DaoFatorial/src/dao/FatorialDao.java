package dao;

import java.util.ArrayList;
import java.util.List;

import model.Fatorial;

public class FatorialDao {
	// aqui eu crio uma lista para receber os meus objetos de Fatorial
	List<Fatorial> listaFatorial;

	// esse método inicializa o meu ArrayList
	public FatorialDao() {
		listaFatorial = new ArrayList<>();
	}

	// aqui eu adiciono um objeto recebido do tipo Fatorial e coloco ele não minha
	// lista
	public void adicionarLista(Fatorial fatorial) {
		listaFatorial.add(fatorial);

		if (listaFatorial.size() > 5) {
			listaFatorial.remove(0);
		}
	}

	// aqui eu retorno a minha lista inteira
	public List retornaLista() {
		return listaFatorial;
	}
}

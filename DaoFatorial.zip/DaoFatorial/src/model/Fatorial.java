package model;

public class Fatorial {
	//aqui eu modelei uma classe para utilizalo ele no meu programa
	
	private int num;

	public Fatorial(int num) {
		this.num = num;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}
